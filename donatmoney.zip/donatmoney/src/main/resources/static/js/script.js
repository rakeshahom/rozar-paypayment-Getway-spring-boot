const paymentStart=()=>{
	console.log("call script function");
	
	var amount = $("#payamount").val();
	
	if(amount == "" || amount == null){
		
		swal("Failed!", "Amount is required.", "error");
		
		return ;
	}
	
	$.ajax({
		url:'/user/create_order',
		data:JSON.stringify({amount:amount,info:'order_request'}),
		contentType:'application/json',
		type:'POST',
		dataType:'JSON',
		success:function(response){
			console.log(response);
			if(response.status=="created"){
				
				var options = {
					    "key": "rzp_test_odJNsDPPZbMU06", // Enter the Key ID
															// generated from
															// the Dashboard
					    "amount": response.amount, // Amount is in currency
													// subunits. Default
													// currency is INR. Hence,
													// 50000 refers to 50000
													// paise
					    "currency": "INR",
					    "name": "activeindia",
					    "description": "Test Transaction",
					    "image": "https://www.google.com/imgres?imgurl=https%3A%2F%2Fassets-global.website-files.com%2F6005fac27a49a9cd477afb63%2F6057684e5923ad2ae43c8150_bavassano_homepage_before.jpg&imgrefurl=https%3A%2F%2Fwww.topazlabs.com%2F&tbnid=8AC2p98LQ_DbXM&vet=12ahUKEwi5qcue7YP1AhWMxjgGHSqRALYQMygXegUIARD4AQ..i&docid=oKOKhliCCm15yM&w=1500&h=1500&itg=1&q=image&ved=2ahUKEwi5qcue7YP1AhWMxjgGHSqRALYQMygXegUIARD4AQ",
					    "order_id": response.id, // This is a sample Order
													// ID. Pass the `id`
													// obtained in the response
													// of Step 1
					    "handler": function (response){
					        console.log(response.razorpay_payment_id);
					        console.log(response.razorpay_order_id);
					        console.log(response.razorpay_signature);
					        console.log("payment successfull...");
					        
					        updatePaymentrOnServer(response.razorpay_payment_id,response.razorpay_order_id,"paid");
					        
					        swal("Congrates!", "payment successfull.", "success");
					    },
					    "prefill": {
					        "name": "",
					        "email": "",
					        "contact": ""
					    },
					    "notes": {
					        "address": "Razorpay Corporate Office"
					    },
					    "theme": {
					        "color": "#3399cc"
					    }
					};
				var rzp1 = new Razorpay(options);
				rzp1.on('payment.failed', function (response){
					console.log(response.error.code);
					console.log(response.error.description);
					console.log(response.error.source);
					console.log(response.error.step);
					console.log(response.error.reason);
					console.log(response.error.metadata.order_id);
					console.log(response.error.metadata.payment_id);
					console.log("payment failed............!");
					
				});
// document.getElementById('payamount').onclick = function(e){
				    rzp1.open();
// e.preventDefault();
// }
				
			}
		},
		error:function(error){
			console.log(error);
			
		}
		});
	
};
function updatePaymentrOnServer(payment_id,order_id,status){
	$.ajax({
		url:'/user/update_order',
		data:JSON.stringify({
			payment_id:payment_id,
			order_id:order_id,
			status:status
			}),
		contentType:'application/json',
		type:'POST',
		dataType:'JSON',
		success:function(response){
			console.log("congrates payment is successfull.....");
			swal("success!", "congrates!! payment successfull.", "success");
		},
		error:function(error){
			console.log("Failed!", "your payment is successfull. but we did not get on server ,we will contact you as soon as posible.", "error");
			swal("Failed!", "your payment is successfull. but we did not get on server ,we will contact you as soon as posible.", "error");
		},
	});
}