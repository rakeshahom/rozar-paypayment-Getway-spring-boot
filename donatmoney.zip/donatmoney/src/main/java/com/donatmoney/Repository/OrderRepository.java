package com.donatmoney.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.donatmoney.Model.MyOrder;

public interface OrderRepository extends JpaRepository<MyOrder, Long> {
public MyOrder findByOrderId(String order_id);
}
