package com.donatmoney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonatmoneyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonatmoneyApplication.class, args);
	}

}
