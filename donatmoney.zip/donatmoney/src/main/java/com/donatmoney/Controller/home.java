package com.donatmoney.Controller;

import java.security.Principal;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.donatmoney.Model.MyOrder;
import com.donatmoney.Repository.OrderRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;

@Controller
public class home {

	@Autowired
	private OrderRepository orderRepository;

	@GetMapping("/home")
	public String payAmount() {
		return "index";

	}

	@PostMapping("/user/create_order")
	@ResponseBody
	public String craeteOrder(@RequestBody Map<String, Object> data, Principal principal) throws Exception {
		int amt = Integer.parseInt(data.get("amount").toString());
		RazorpayClient client = new RazorpayClient("rzp_test_odJNsDPPZbMU06", "2JXvBYfz4NPqYJSrWVIdbrc8");
		JSONObject obj = new JSONObject();
		obj.put("amount", amt * 100);
		obj.put("currency", "INR");
		obj.put("receipt", "txn_235425");

		Order order = client.Orders.create(obj);
//dave data in my databse start...............for this user principal argument................................
		MyOrder myOrder = new MyOrder();

		myOrder.setAmount(order.get("amount") + "");
		myOrder.setOrderId(order.get("id"));
		myOrder.setPaymentId(order.get(null));
		myOrder.setStatus(order.get("created"));
//		myOrder.setUser(this.userRepository.getUserByName(principal.getName()));
		myOrder.setReceipt(order.get("receipt"));
		this.orderRepository.save(myOrder);
//dave data in my databse end.................................
		System.out.println(order);
		return order.toString();
	}

	@PostMapping("/user/update_order")
	public ResponseEntity<?> updateOrder(@RequestBody Map<String, Object> data) {
		MyOrder myOrder = this.orderRepository.findByOrderId(data.get("order_id").toString());
		myOrder.setPaymentId(data.get("payment_id").toString());
		myOrder.setStatus(data.get("status").toString());
		this.orderRepository.save(myOrder);
		System.out.println(data);
		return ResponseEntity.ok("update successfully..");
	}
}
